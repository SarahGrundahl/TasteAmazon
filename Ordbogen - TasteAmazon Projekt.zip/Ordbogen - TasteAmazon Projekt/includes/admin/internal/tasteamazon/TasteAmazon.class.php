<?php
namespace includes\admin\internal\tasteamazon;

class TasteAmazon extends \includes\mom\MOMSimple
{
    const DB = 'tasteamazon';
}
