<?php
/* Smarty version 3.1.32, created on 2018-07-03 11:53:58
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\elements\hero.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b3b63d6a415c2_67370391',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '15c5b725364989c6c2dfcfed6646cc1353471a83' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\elements\\hero.tpl',
      1 => 1530618835,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b3b63d6a415c2_67370391 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="container">
  <div class="col-md-12">
    <img src="img/hero_logo.png" width="50%" height="auto" alt="Larger logo of TasteAmazon">
  </div>
</div>
<!-- <div class="col-md-12">
  <img src="img/hero.png" width="100%" height="auto" alt="Hero image for TasteAmazon">
</div> -->
<?php }
}
