<?php
/* Smarty version 3.1.32, created on 2018-07-10 06:57:51
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b4458ef9fcf67_87254968',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4a0db1b841e076d90c8baed8f0d2834e415f38b2' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\footer.tpl',
      1 => 1531205869,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b4458ef9fcf67_87254968 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- <div class="bg-dark" style="padding:30px 0">
  <div class="container-fluid row text-white">
    <div class="col-md-6 text-right">
      <a href="#smiley-rapport">
        <img src="img/smiley-rapport.gif" alt="Smiley rapport">
      </a>
    </div>
    <div class="col-md-6">
      <span>TasteAmazon</span><br>
      <span>Valby Tingsted 6, st.</span><br>
      <span>2500 Valby</span><br>
      <span>CVR 37798452</span><br>
    </div>
    <div class="col-md-12 text-center" style="padding-top:20px">
      2016 © TasteAmazon. All Rights Reserved.
    </div>
  </div>
</div> -->
<?php }
}
