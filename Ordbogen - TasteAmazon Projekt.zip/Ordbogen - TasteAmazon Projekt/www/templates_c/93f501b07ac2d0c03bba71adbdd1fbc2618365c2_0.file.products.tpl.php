<?php
/* Smarty version 3.1.32, created on 2018-07-03 19:01:35
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\elements\products.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b3bc80fb85af9_40573235',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '93f501b07ac2d0c03bba71adbdd1fbc2618365c2' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\elements\\products.tpl',
      1 => 1530644480,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b3bc80fb85af9_40573235 (Smarty_Internal_Template $_smarty_tpl) {
?><div style="background-color: #F6F6F4; padding: 30px 0;">
  <div class="container">
    <h2 class="text-uppercase">Acai Produkter</h2>
    <div class="row">
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['products']->value, 'product');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['product']->value) {
?>
      <div id="product-<?php echo $_smarty_tpl->tpl_vars['product']->value->id;?>
" class="col-md">
        <img class="rounded-circle border border-dark" src="img/products/product_1.jpg" width="290px" height="290px" alt="Produkt 1">
        <h3><?php echo $_smarty_tpl->tpl_vars['product']->value->title;?>
</h3>
      </div>
      <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </div>
  </div>
</div>
<?php }
}
