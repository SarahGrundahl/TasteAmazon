<?php
/* Smarty version 3.1.32, created on 2018-07-02 12:53:09
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\elements\recipes.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b3a2035333f31_71558015',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '57dbf6e53c438e7fed93bd56f3b345c829647d8a' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\elements\\recipes.tpl',
      1 => 1530523446,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b3a2035333f31_71558015 (Smarty_Internal_Template $_smarty_tpl) {
?><div style="background-color: #F6F6F4; padding: 30px 0;">
  <div class="container">
    <h2 class="text-uppercase">Acai bær kan bruges i mange opskrifter</h2>
    <div class="row">
      <div class="col-md">
        <img class="rounded-circle border border-dark" src="img/recipes/acai-1.jpg" width="290px" height="290px" alt="Produkt 1">
        <h3>Acai skål med banan</h3>
      </div>
    </div>
  </div>
</div>
<?php }
}
