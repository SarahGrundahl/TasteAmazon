<?php
/* Smarty version 3.1.32, created on 2018-07-02 12:53:09
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\elements\add_product.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b3a2035257793_64085750',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fce7e28b307dc0edfc7185dfcfaa8534c292b0e7' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\elements\\add_product.tpl',
      1 => 1529757743,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b3a2035257793_64085750 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="add_product">
  <input type="text" name="title" placeholder="Titel"/>
  <input type="text" name="text" placeholder="Tekst"/>
  <input type="text" name="description" placeholder="Beskrivelse"/>
  <input type="file" name="image" placeholder="Billede"/>
</div>
<button class="btn" type="button" style="border-radius: 200px;" onclick="Product.add()">Tilføj</button>
<?php }
}
