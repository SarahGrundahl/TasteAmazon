<?php
/* Smarty version 3.1.32, created on 2018-07-09 20:43:01
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\admin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b43c8d527de88_74108090',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'abec34d45d35f2f81f9c0bed5ee62c9ebbe212f2' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\admin.tpl',
      1 => 1531168978,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:pages/widgets/admin_dashboard.tpl' => 1,
  ),
),false)) {
function content_5b43c8d527de88_74108090 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11879449635b43c8d5256f31_60122347', 'javascript');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_14047904875b43c8d525aa22_50884001', 'css');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1783279895b43c8d525c492_75486610', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, 'master.tpl');
}
/* {block 'javascript'} */
class Block_11879449635b43c8d5256f31_60122347 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'javascript' => 
  array (
    0 => 'Block_11879449635b43c8d5256f31_60122347',
  ),
);
public $append = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="../www/javascripts/init.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="../www/javascripts/tasteamazon/Menu.class.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="../www/javascripts/tasteamazon/Login.class.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="../www/javascripts/tasteamazon/Product.class.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="../www/javascripts/tasteamazon/Gallery.class.js"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'javascript'} */
/* {block 'css'} */
class Block_14047904875b43c8d525aa22_50884001 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'css' => 
  array (
    0 => 'Block_14047904875b43c8d525aa22_50884001',
  ),
);
public $append = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<link rel="stylesheet" href="../www/css/style.css">
<link rel="stylesheet" href="../www/css/admin.css">
<?php
}
}
/* {/block 'css'} */
/* {block 'content'} */
class Block_1783279895b43c8d525c492_75486610 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1783279895b43c8d525c492_75486610',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>





<nav class="navbar navbar-expand-lg navbar-light fixed-top" style="background:#512E90">
  <a class="navbar-brand" href="#dashboard"><img src="img/logo-mobile.png" width:"50" height="40" alt="TasteAmazon Logo"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#adminNav" aria-controls="adminNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="text-uppercase collapse navbar-collapse" id="adminNav">
    <ul class="navbar-nav ml-auto">
      <li id="menu-frontpage" class="nav-item">
        <a class="nav-link text-light">Indstillinger</a>
      </li>
      <li id="menu-products" class="nav-item">
        <a class="nav-link text-light" onclick="Menu.getProfilePage()">Profil</a>
      </li>
      <li id="menu-gallery" class="nav-item">
        <a class="nav-link text-light" onclick="Menu.getFrontPage()">Log ud</a>
      </li>
    </ul>
  </div>
</nav>


<div class="container-fluid bg-light">
  <div class="row">
    <div class="col-md-2 bg-dark text-white" style="padding:0; height:100vh; padding-top:65px;">
      <div class="row" style="padding:10px 15px">
        <div class="col-md-3">
          <img class="bg-white rounded-circle" src="img/logo.png" width="40px" height="40px" alt="">
        </div>
        <div class="col-md-9">
          <h5>TasteAmazon</h5>
          <span>Administrator</span>
        </div>
      </div>
      <ul class="nav nav-pills col-md-12 container-fluid" style="padding:0">
        <a class="admin-nav text-white" href="#dashboard" onclick="Menu.getAdminDashboardPage()" style="width:100%">
          <li role="presentation" id="tabMenu-dashboard" class="tabMenu active padding-10 background-black">
            <div class="row">
              <div class="col-md-2">
                <img src="img/admin/dashboard.png" width="25px" height="25px" alt="">
              </div>
              <div class="col-md-10">
                <span>Kontrolpanel</span>
              </div>
            </div>
          </li>
        </a>
        <a class="admin-nav text-white" href="#products" onclick="Menu.getAddProductsPage()" style="width:100%">
          <li role="presentation" id="tabMenu-products" class="tabMenu padding-10">
            <div class="row">
              <div class="col-md-2">
                <img src="img/admin/computer.png" width="25px" height="25px" alt="">
              </div>
              <div class="col-md-10">
                <span>Produkter</span>
              </div>
            </div>
          </li>
        </a>
        <a class="admin-nav text-white" href="#gallery" onclick="Menu.getAddGalleryPage()" style="width:100%">
          <li role="presentation" id="tabMenu-gallery" class="tabMenu padding-10">
            <div class="row">
              <div class="col-md-2">
                <img src="img/admin/camera.png" width="25px" height="25px" alt="">
              </div>
              <div class="col-md-10">
                <span>Galleri</span>
              </div>
            </div>
          </li>
        </a>
        <a class="admin-nav text-white" href="#recipes" style="width:100%">
          <li role="presentation" id="admin-recipes" class="padding-10">
            <div class="row">
              <div class="col-md-2">
                <img src="img/admin/cookbook.png" width="25px" height="25px" alt="">
              </div>
              <div class="col-md-10">
                <span>Opskrifter</span>
              </div>
            </div>
          </li>
        </a>
      </ul>
    </div>
    <div class="tab-content col-md-10" style="margin-top:65px;">

      <div id="admin-content">
        <div id="admin_dashboard" class="admin-menu tab-pane">
            <?php $_smarty_tpl->_subTemplateRender("file:pages/widgets/admin_dashboard.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        </div>
        <div id="admin_products" class="admin-menu tab-pane">
        </div>
        <div id="admin_gallery" class="admin-menu tab-pane">
        </div>
      </div>
    </div>
  </div>
</div>















<?php
}
}
/* {/block 'content'} */
}
