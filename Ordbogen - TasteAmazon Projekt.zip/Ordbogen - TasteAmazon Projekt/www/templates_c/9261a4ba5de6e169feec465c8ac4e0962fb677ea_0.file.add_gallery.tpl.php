<?php
/* Smarty version 3.1.32, created on 2018-07-02 12:53:09
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\elements\add_gallery.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b3a20352fba07_68242161',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9261a4ba5de6e169feec465c8ac4e0962fb677ea' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\elements\\add_gallery.tpl',
      1 => 1529757634,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b3a20352fba07_68242161 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="add_picture">
  <input type="text" name="title" placeholder="Titel"/>
  <input type="file" name="image" placeholder="Billede"/>
</div>
<button class="btn" type="button" style="border-radius: 200px;" onclick="Gallery.add()">Tilføj</button>
<?php }
}
