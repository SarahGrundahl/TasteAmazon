<?php
/* Smarty version 3.1.32, created on 2018-07-10 07:03:36
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b445a4897b258_61404774',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '572385400cafe9313adf4416e43f3b324c38cdb4' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\header.tpl',
      1 => 1531206214,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b445a4897b258_61404774 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html>
  <head>
      <title><?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</title>
            <link rel="icon" type="image/png" href="img/favicon/favicon-16.png" sizes="16x16">
      <link rel="icon" type="image/png" href="img/favicon/favicon-32.png" sizes="32x32">

            <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11403875365b445a48978f49_21936647', 'css');
?>


            <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15691155915b445a48979da2_19212659', 'javascript');
?>

  </head>
<body>
<?php }
/* {block 'css'} */
class Block_11403875365b445a48978f49_21936647 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'css' => 
  array (
    0 => 'Block_11403875365b445a48978f49_21936647',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

      <link rel="stylesheet" href="../www/css/admin.css">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
      <?php
}
}
/* {/block 'css'} */
/* {block 'javascript'} */
class Block_15691155915b445a48979da2_19212659 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'javascript' => 
  array (
    0 => 'Block_15691155915b445a48979da2_19212659',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

      <?php echo '<script'; ?>
 type="text/javascript" src="/www/javascripts/jsonrpc2.js"><?php echo '</script'; ?>
>
      <?php echo '<script'; ?>
 src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"><?php echo '</script'; ?>
>
      <?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"><?php echo '</script'; ?>
>
      <?php echo '<script'; ?>
 type="text/javascript" src="/www/javascripts/components/notify.min.js"><?php echo '</script'; ?>
>
      <?php echo '<script'; ?>
 type="text/javascript" src="/www/javascripts/Admin.class.js"><?php echo '</script'; ?>
>
      <?php echo '<script'; ?>
 type="text/javascript" src="/www/javascripts/FormUtil.class.js"><?php echo '</script'; ?>
>
      <?php
}
}
/* {/block 'javascript'} */
}
