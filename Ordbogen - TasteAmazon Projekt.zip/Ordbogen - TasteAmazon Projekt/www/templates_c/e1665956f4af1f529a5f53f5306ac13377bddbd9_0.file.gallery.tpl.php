<?php
/* Smarty version 3.1.32, created on 2018-07-09 22:36:27
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\elements\gallery.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b43e36b27dfa0_01777222',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e1665956f4af1f529a5f53f5306ac13377bddbd9' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\elements\\gallery.tpl',
      1 => 1531175784,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b43e36b27dfa0_01777222 (Smarty_Internal_Template $_smarty_tpl) {
?><div style="background-color: #9778D3; padding: 30px 0;">
  <div class="container">
    <h2 class="text-uppercase" style="color:white;">Galleri</h2>
    <div class="row">
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['gallery']->value, 'picture');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['picture']->value) {
?>
      <div id="gallery-<?php echo $_smarty_tpl->tpl_vars['picture']->value->id;?>
" class="col-md">
        <img class="border border-dark" src="img/gallery/1.jpg" width="315px" height="auto" alt="Produkt 1">
        <h3 class="text-center text-white" style="margin:15px 0;"><?php echo $_smarty_tpl->tpl_vars['picture']->value->title;?>
</h3>
      </div>
      <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </div>
  </div>
</div>
<?php }
}
