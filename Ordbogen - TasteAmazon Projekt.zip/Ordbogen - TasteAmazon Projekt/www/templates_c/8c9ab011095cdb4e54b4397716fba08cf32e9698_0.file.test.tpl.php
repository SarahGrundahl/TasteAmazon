<?php
/* Smarty version 3.1.32, created on 2018-07-02 12:59:42
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\test.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b3a21be24b3e0_61375212',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8c9ab011095cdb4e54b4397716fba08cf32e9698' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\test.tpl',
      1 => 1530536375,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b3a21be24b3e0_61375212 (Smarty_Internal_Template $_smarty_tpl) {
?>test
sdfsdfsd
<?php }
}
