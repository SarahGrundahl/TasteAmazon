<?php
/* Smarty version 3.1.32, created on 2018-07-09 20:42:01
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\widgets\admin_dashboard.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b43c899b470d8_30323867',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5425b1fca75e6fae75e51458dea508f306e8def9' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\widgets\\admin_dashboard.tpl',
      1 => 1531168907,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b43c899b470d8_30323867 (Smarty_Internal_Template $_smarty_tpl) {
?><h2 class="col-md-12 page-header bg-white shadow-sm border border-top-0 rounded-bottom" style="padding-bottom:5px;margin-bottom:15px">
  <img class="text-center" src="img/admin/dashboard-sort.png" width="35" height="35">
  Kontrolpanel
</h2>
<div class="row">
  <div class="col-md-4">
    <div class="col-md-12 shadow-sm border rounded" style="margin-bottom:15px">
      <div class="row">
        <div class="col-md-3 bg-warning rounded-left" style="padding-top:10px; padding-bottom:10px">
          <img class="text-center" src="img/admin/users.png" width="50" height="50" alt="Generic placeholder thumbnail">
        </div>
        <div class="col-md-9 bg-white" style="padding:10px">
          <h5>Medlemmer</h5>
          <span>5</span>
        </div>
      </div>
    </div>
    <div class="col-md-12 shadow-sm border rounded" style="margin-bottom:15px">
      <div class="row">
        <div class="col-md-3 bg-info rounded-left" style="padding-top:10px; padding-bottom:10px">
          <img src="img/admin/computer.png" width="50" height="50" alt="Generic placeholder thumbnail">
        </div>
        <div class="col-md-9 bg-white" style="padding:10px">
          <h5>Produkter</h5>
          <span><?php echo count($_smarty_tpl->tpl_vars['products']->value);?>
</span>
        </div>
      </div>
    </div>
    <div class="col-md-12 shadow-sm border rounded" style="margin-bottom:15px">
      <div class="row">
        <div class="col-md-3 bg-danger rounded-left" style="padding-top:10px; padding-bottom:10px">
          <img class="text-center" src="img/admin/camera.png" width="50" height="50" alt="Generic placeholder thumbnail">
        </div>
        <div class="col-md-9 bg-white" style="padding:10px">
          <h5>Billeder</h5>
          <span><?php echo count($_smarty_tpl->tpl_vars['gallery']->value);?>
</span>
        </div>
      </div>
    </div>
    <div class="col-md-12 shadow-sm border rounded" style="margin-bottom:15px">
      <div class="row">
        <div class="col-md-3 bg-primary rounded-left" style="padding-top:10px; padding-bottom:10px">
          <img class="text-center" src="img/admin/cookbook.png" width="50" height="50" alt="Generic placeholder thumbnail">
        </div>
        <div class="col-md-9 bg-white" style="padding:10px">
          <h5>Opskrifter</h5>
          <span>1</span>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-8">
    <div class="col-md-12 bg-white shadow-sm border rounded" style="padding:10px;">
      <h4>Hej Martin og Dennis</h4>
      <img class="rounded" src="img/admin/team.jpg" width="80%" alt="">
    </div>
  </div>
</div>
<?php }
}
