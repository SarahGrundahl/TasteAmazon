<?php
/* Smarty version 3.1.32, created on 2018-07-10 07:03:36
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b445a48937ba5_43129311',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '61a6c9e4d05e1a6f306d968f3960af5f46641375' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\index.tpl',
      1 => 1531206201,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:pages/widgets/nav_bar.tpl' => 1,
    'file:pages/widgets/Frontpage.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5b445a48937ba5_43129311 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19960107465b445a4892e1e8_84917950', 'javascript');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2306773995b445a4892f589_68431090', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, 'master.tpl');
}
/* {block 'javascript'} */
class Block_19960107465b445a4892e1e8_84917950 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'javascript' => 
  array (
    0 => 'Block_19960107465b445a4892e1e8_84917950',
  ),
);
public $append = 'true';
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="../www/javascripts/init.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="../www/javascripts/tasteamazon/Menu.class.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="../www/javascripts/tasteamazon/Login.class.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="../www/javascripts/tasteamazon/Product.class.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="../www/javascripts/tasteamazon/Gallery.class.js"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'javascript'} */
/* {block 'content'} */
class Block_2306773995b445a4892f589_68431090 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_2306773995b445a4892f589_68431090',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="page-container">
  <?php $_smarty_tpl->_subTemplateRender("file:pages/widgets/nav_bar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
  <div class="tabs" style="margin-top: 100px;">
    <div class="tab-content">
        <div id="frontpage" class="tab-pane">
            <?php $_smarty_tpl->_subTemplateRender("file:pages/widgets/Frontpage.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        </div>
        <div id="products" class="tab-pane">
        </div>
        <div id="gallery" class="tab-pane">
        </div>
        <div id="login" class="tab-pane">
        </div>
    </div>
  </div>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
</div>
<?php
}
}
/* {/block 'content'} */
}
