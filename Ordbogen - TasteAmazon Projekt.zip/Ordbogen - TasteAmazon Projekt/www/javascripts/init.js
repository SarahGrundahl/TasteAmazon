$(document).ready(function(){
  $('#frontpage').addClass('active');
});
