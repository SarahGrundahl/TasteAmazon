Admin = {
	rpc: new JsonRpcClient('/www/api/json.php'),
}
