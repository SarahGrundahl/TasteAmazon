<?php
/* Smarty version 3.1.32, created on 2018-07-02 13:14:50
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\test.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b3a254aa964a2_42445196',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '68d716a3a3d19017e245293bbfb54cc1efb8c840' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\test.tpl',
      1 => 1530536375,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b3a254aa964a2_42445196 (Smarty_Internal_Template $_smarty_tpl) {
?>test
sdfsdfsd
<?php }
}
