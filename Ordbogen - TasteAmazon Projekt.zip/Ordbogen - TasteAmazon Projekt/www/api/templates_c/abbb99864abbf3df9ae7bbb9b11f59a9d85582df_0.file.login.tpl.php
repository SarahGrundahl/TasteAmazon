<?php
/* Smarty version 3.1.32, created on 2018-07-03 06:53:56
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\widgets\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b3b1d84b8f825_25878249',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'abbb99864abbf3df9ae7bbb9b11f59a9d85582df' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\widgets\\login.tpl',
      1 => 1530273682,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b3b1d84b8f825_25878249 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="container" style="width:300px; margin-top:100px;">
   <div class="card card-container" style="padding: 10px;">
       <img id="profile-img" class="m-auto" src="img/logo.png" width="200px" style="margin-top: 15px;"/>
       <p id="profile-name" class="profile-name-card"></p>
       <div id="login_form" class="form-signin">
           <span id="reauth-email" class="reauth-email"></span>
           <input type="text" name="username" class="form-control" placeholder="Brugernavn" required autofocus style="margin: 5px 0;">
           <input type="password" name="password" class="form-control" placeholder="Adgangskode" required style="margin: 5px 0;">
           <button class="btn btn-md btn-primary btn-block btn-signin" onclick="Login.login()" style="margin: 10px 0;">Login</button>
       </div>
       <a href="#" class="forgot-password">
           Glemt adgangskode?
       </a>
   </div>
</div>
<?php }
}
