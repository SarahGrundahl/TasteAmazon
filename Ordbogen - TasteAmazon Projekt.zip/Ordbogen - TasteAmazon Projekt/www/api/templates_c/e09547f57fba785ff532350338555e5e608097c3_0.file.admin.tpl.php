<?php
/* Smarty version 3.1.32, created on 2018-07-03 11:08:44
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\widgets\admin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b3b593c02fd75_60813355',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e09547f57fba785ff532350338555e5e608097c3' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\widgets\\admin.tpl',
      1 => 1530616113,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b3b593c02fd75_60813355 (Smarty_Internal_Template $_smarty_tpl) {
?><h1>Hej Admin, du er nu logget ind</h1>
<?php }
}
