<?php
/* Smarty version 3.1.32, created on 2018-07-09 22:32:27
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\widgets\product_item.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b43e27b116271_62021325',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fa6699ab9663fa423e217095f999ed9c7a48ed16' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\widgets\\product_item.tpl',
      1 => 1531175530,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b43e27b116271_62021325 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="product-item" class="container" style="margin-top: 100px;">
  <a href="#frontpage" onclick="Menu.getFrontpageHtml()"><img src="img/icons/home.png" width="20px" alt="Forside"></a> <span>/</span>
  <a href="#products" onclick="Menu.getProductHtml(true)">Produkter</a> <span>/</span>
  <a href="#product-<?php echo $_smarty_tpl->tpl_vars['product']->value->id;?>
"><?php echo $_smarty_tpl->tpl_vars['product']->value->title;?>
</a>
  <div class="row">
    <div class="col-md-7 m-auto">
      <div id="product" class="text-center m-auto">
        <img class="rounded-circle border border-dark" src="img/products/product_1.jpg" width="290px" height="290px" alt="Produkt 1">
      </div>
    </div>
    <div class="col-md-5">
      <h1><?php echo $_smarty_tpl->tpl_vars['product']->value->title;?>
</h1>
      <ul id="myTabs" class="nav nav-pills col-md-12">
        <li class="border rounded-top border-bottom-0 active col-md-5"><a data-toogle="pill" onclick="Menu.getTabDescription()">Beskrivelse</a></li>
        <li class="border rounded-top border-bottom-0 col-md-5"><a data-toogle="pill" onclick="Menu.getTabFoodContent()">Indholdsfortegnelse</a></li>
      </ul>
      <div class="col-md-12 border" style="min-height:200px;">
        <?php echo $_smarty_tpl->tpl_vars['product']->value->text;?>

      </div>
    </div>
  </div>
</div>
<?php }
}
