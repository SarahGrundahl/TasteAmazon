<?php
/* Smarty version 3.1.32, created on 2018-07-02 13:46:21
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\widgets\Products.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b3a2cad1cc9a0_45046103',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f35477a2a5b012eae6f67691265dc29bc62823ad' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\widgets\\Products.tpl',
      1 => 1530539176,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b3a2cad1cc9a0_45046103 (Smarty_Internal_Template $_smarty_tpl) {
?><div style="margin-top: 100px;">
  <div class="container">
    <h1 class="text-uppercase text-center" style="margin-bottom:50px;">Acai produkter</h1>
    <div class="row">
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['products']->value, 'product');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['product']->value) {
?>
      <div id="product-<?php echo $_smarty_tpl->tpl_vars['product']->value->id;?>
" class="col-md-3">
        <img class="rounded-circle border border-dark" src="img/products/product_1.jpg" width="100%" alt="Produkt 1">
        <h3 class="text-center" style="margin:15px 0;"><?php echo $_smarty_tpl->tpl_vars['product']->value->title;?>
</h3>
      </div>
      <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </div>
  </div>
</div>
<?php }
}
