<?php
/* Smarty version 3.1.32, created on 2018-07-10 07:26:26
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\elements\add_gallery.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b445fa2918c63_10567381',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9261a4ba5de6e169feec465c8ac4e0962fb677ea' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\elements\\add_gallery.tpl',
      1 => 1531207572,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b445fa2918c63_10567381 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="add_picture">
  <h4>Opret billede</h4>
  <div class="form-group">
    <small for="title" class="form-text text-muted">Titel</small>
    <input type="text" name="title" class="form-control">
  </div>
  <div class="form-group">
    <small for="image" class="form-text text-muted">Billede</small>
    <input type="file" name="image" class="form-control">
  </div>
</div>
<button class="btn" type="button" style="border-radius: 200px;" onclick="Gallery.add()">Tilføj billede</button>
<?php }
}
