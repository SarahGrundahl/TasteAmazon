<?php
/* Smarty version 3.1.32, created on 2018-07-10 07:28:04
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\widgets\admin_products.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b44600412d098_63674239',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '84176c3d310f637b5d361f58859d47d337c97929' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\widgets\\admin_products.tpl',
      1 => 1531207672,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:pages/elements/add_product.tpl' => 1,
  ),
),false)) {
function content_5b44600412d098_63674239 (Smarty_Internal_Template $_smarty_tpl) {
?><h2 class="col-md-12 page-header bg-white shadow-sm border border-top-0 rounded-bottom" style="padding-bottom:5px;margin-bottom:15px">
  <img class="text-center" src="img/admin/computer-black.png" width="35" height="35">
  Produkter
</h2>
<div class="row">
  <div class="col-md-4">
    <div class="col-md-12 bg-white shadow-sm border rounded padding-10">
      <?php $_smarty_tpl->_subTemplateRender("file:pages/elements/add_product.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    </div>
  </div>

  <div id="products-table" class="col-md-8">
    <div class="col-md-12 bg-white shadow-sm border rounded padding-10">
      <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">Billede</th>
            <th scope="col">Titel</th>
            <th scope="col">Tekst</th>
            <th scope="col">Beskrivelse</th>
          </tr>
        </thead>
        <tbody>
          <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['products']->value, 'product');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['product']->value) {
?>
          <tr>
            <td><img src="img/products/<?php echo $_smarty_tpl->tpl_vars['product']->value->image;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['product']->value->title;?>
"></td>
            <td><?php echo $_smarty_tpl->tpl_vars['product']->value->title;?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['product']->value->text;?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['product']->value->description;?>
</td>
          </tr>
          <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php }
}
