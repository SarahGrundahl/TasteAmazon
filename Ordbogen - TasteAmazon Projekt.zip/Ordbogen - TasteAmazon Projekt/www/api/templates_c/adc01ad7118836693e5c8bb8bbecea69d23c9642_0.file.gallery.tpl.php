<?php
/* Smarty version 3.1.32, created on 2018-07-09 22:35:21
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\widgets\gallery.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b43e32902fc52_04407033',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'adc01ad7118836693e5c8bb8bbecea69d23c9642' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\widgets\\gallery.tpl',
      1 => 1531175715,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b43e32902fc52_04407033 (Smarty_Internal_Template $_smarty_tpl) {
?><div style="margin-top: 100px;">
  <div class="container">
    <div class="row">
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['gallery']->value, 'picture');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['picture']->value) {
?>
      <div id="gallery-<?php echo $_smarty_tpl->tpl_vars['picture']->value->id;?>
" class="col-md-3">
        <img class="border border-dark" src="img/gallery/1.jpg" width="100%" height="auto" alt="Produkt 1">
        <h3 class="text-center" style="margin:15px 0;"><?php echo $_smarty_tpl->tpl_vars['picture']->value->title;?>
</h3>
      </div>
      <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </div>
  </div>
</div>
<?php }
}
