<?php
/* Smarty version 3.1.32, created on 2018-07-07 21:11:55
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\elements\add_product.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b412c9bb923a8_24089328',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fce7e28b307dc0edfc7185dfcfaa8534c292b0e7' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\elements\\add_product.tpl',
      1 => 1530997904,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b412c9bb923a8_24089328 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="add_product">
  <h4>Opret produkt</h4>
  <div class="form-group">
    <small for="title" class="form-text text-muted">Titel</small>
    <input type="text" name="title" class="form-control">
  </div>
  <div class="form-group">
    <small for="text" class="form-text text-muted">Tekst</small>
    <input type="text" name="text" class="form-control">
  </div>
  <div class="form-group">
    <small for="description" class="form-text text-muted">Beskrivelse</small>
    <input type="text" name="description" class="form-control">
  </div>
  <div class="form-group">
    <small for="image" class="form-text text-muted">Billede</small>
    <input type="file" name="image" class="form-control">
  </div>
</div>
<button class="btn" type="button" style="border-radius: 200px;" onclick="Product.add()">Tilføj produkt</button>
<?php }
}
