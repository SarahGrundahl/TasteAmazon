<?php
/* Smarty version 3.1.32, created on 2018-07-10 07:28:47
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\pages\admin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b44602fad9db6_96025871',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'abec34d45d35f2f81f9c0bed5ee62c9ebbe212f2' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\pages\\admin.tpl',
      1 => 1531207719,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:pages/widgets/admin_dashboard.tpl' => 1,
  ),
),false)) {
function content_5b44602fad9db6_96025871 (Smarty_Internal_Template $_smarty_tpl) {
?><nav class="navbar navbar-expand-lg navbar-light fixed-top" style="background:#512E90">
  <a class="navbar-brand" href="#dashboard" onclick="Menu.getAdminDashboardPage()"><img src="img/logo-mobile.png" width:"50" height="40" alt="TasteAmazon Logo"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#adminNav" aria-controls="adminNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="text-uppercase collapse navbar-collapse" id="adminNav">
    <ul class="navbar-nav ml-auto">
      <li id="menu-frontpage" class="nav-item">
        <a href="#settings" class="nav-link text-light">Indstillinger</a>
      </li>
      <li id="menu-products" class="nav-item">
        <a href="#profile" class="nav-link text-light">Profil</a>
      </li>
      <li id="menu-gallery" class="nav-item">
        <a href="#logout" class="nav-link text-light" onclick="Menu.getFrontpageHtml()">Log ud</a>
      </li>
    </ul>
  </div>
</nav>
<div class="container-fluid bg-light">
  <div class="row">
    <div class="col-md-2 bg-dark text-white" style="padding:0; height:100vh; padding-top:65px;">
      <div class="row" style="padding:10px 15px">
        <div class="col-md-3">
          <img class="bg-white rounded-circle" src="img/logo.png" width="40px" height="40px" alt="">
        </div>
        <div class="col-md-9">
          <h5>TasteAmazon</h5>
          <span>Administrator</span>
        </div>
      </div>
      <ul class="nav nav-pills col-md-12 container-fluid" style="padding:0">
        <a class="admin-nav text-white" href="#dashboard" onclick="Menu.getAdminDashboardPage()" style="width:100%">
          <li role="presentation" id="tabMenu-dashboard" class="tabMenu active padding-10 background-black">
            <div class="row">
              <div class="col-md-2">
                <img src="img/admin/dashboard.png" width="25px" height="25px" alt="">
              </div>
              <div class="col-md-10">
                <span>Kontrolpanel</span>
              </div>
            </div>
          </li>
        </a>
        <a class="admin-nav text-white" href="#products" onclick="Menu.getAddProductsPage()" style="width:100%">
          <li role="presentation" id="tabMenu-products" class="tabMenu padding-10">
            <div class="row">
              <div class="col-md-2">
                <img src="img/admin/computer.png" width="25px" height="25px" alt="">
              </div>
              <div class="col-md-10">
                <span>Produkter</span>
              </div>
            </div>
          </li>
        </a>
        <a class="admin-nav text-white" href="#gallery" onclick="Menu.getAddGalleryPage()" style="width:100%">
          <li role="presentation" id="tabMenu-gallery" class="tabMenu padding-10">
            <div class="row">
              <div class="col-md-2">
                <img src="img/admin/camera.png" width="25px" height="25px" alt="">
              </div>
              <div class="col-md-10">
                <span>Galleri</span>
              </div>
            </div>
          </li>
        </a>
        <a class="admin-nav text-white" href="#recipes" style="width:100%">
          <li role="presentation" id="admin-recipes" class="padding-10">
            <div class="row">
              <div class="col-md-2">
                <img src="img/admin/cookbook.png" width="25px" height="25px" alt="">
              </div>
              <div class="col-md-10">
                <span>Opskrifter</span>
              </div>
            </div>
          </li>
        </a>
      </ul>
    </div>
    <div class="tab-content col-md-10" style="margin-top:65px;">
      <div id="admin-content">
        <div id="admin_dashboard" class="admin-menu tab-pane">
            <?php $_smarty_tpl->_subTemplateRender("file:pages/widgets/admin_dashboard.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        </div>
        <div id="admin_products" class="admin-menu tab-pane">
        </div>
        <div id="admin_gallery" class="admin-menu tab-pane">
        </div>
      </div>
    </div>
  </div>
</div>
<?php }
}
