<?php
/* Smarty version 3.1.32, created on 2018-06-15 06:46:28
  from 'C:\Users\Sarah\Desktop\jQueryFirstRepository-\smarty_php\www\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b2360c4225e53_17276775',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1f561d53ed6cfa243cb9d3515ae2c7134f2b9bc9' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\jQueryFirstRepository-\\smarty_php\\www\\templates\\index.tpl',
      1 => 1528889804,
      2 => 'file',
    ),
    '76c3f6acd8e78f8d7aa31a0fe52a48666c2ad1d6' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\jQueryFirstRepository-\\smarty_php\\www\\templates\\header.tpl',
      1 => 1528890740,
      2 => 'file',
    ),
    'c785e74d3461940f5e55bb2565784d896d3c1ff1' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\jQueryFirstRepository-\\smarty_php\\www\\templates\\footer.tpl',
      1 => 1524581613,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5b2360c4225e53_17276775 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
<head>
    <title>Dette er min test side til tasteamazon.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
</head>
<body>
    <button class="btn btn-primary">Dette er min test side til tasteamazon.com - :P</button>
</BODY>
</HTML>
<?php }
}
