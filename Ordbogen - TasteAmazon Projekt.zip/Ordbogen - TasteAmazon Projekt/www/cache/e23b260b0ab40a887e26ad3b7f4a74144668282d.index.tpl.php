<?php
/* Smarty version 3.1.32, created on 2018-06-19 12:30:47
  from 'C:\Users\Sarah\Desktop\Ordbogen - TasteAmazon Projekt\www\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b28f7773ec1c3_76064263',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e927b776e68f40dae434a8a07c14b9b675fc541d' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\Ordbogen - TasteAmazon Projekt\\www\\templates\\index.tpl',
      1 => 1529411294,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5b28f7773ec1c3_76064263 (Smarty_Internal_Template $_smarty_tpl) {
?><h1>hej</h1>
<?php }
}
