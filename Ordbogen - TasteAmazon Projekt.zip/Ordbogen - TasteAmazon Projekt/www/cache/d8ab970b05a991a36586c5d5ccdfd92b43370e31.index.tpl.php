<?php
/* Smarty version 3.1.32, created on 2018-06-13 11:54:29
  from 'C:\Users\Sarah\Desktop\jQueryFirstRepository-\smarty_php\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b2105f5b7fa37_51252599',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5291af199e333a68bf9b7f00819df008644be90a' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\jQueryFirstRepository-\\smarty_php\\templates\\index.tpl',
      1 => 1528889804,
      2 => 'file',
    ),
    '79797c019d93a013213a1f1bf7d0ea6c30bbdcf3' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\jQueryFirstRepository-\\smarty_php\\templates\\header.tpl',
      1 => 1528890740,
      2 => 'file',
    ),
    'cc2e83eb8ce8af8585bf0ca2d9190e4d1550a970' => 
    array (
      0 => 'C:\\Users\\Sarah\\Desktop\\jQueryFirstRepository-\\smarty_php\\templates\\footer.tpl',
      1 => 1524581613,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5b2105f5b7fa37_51252599 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
<head>
    <title>Dette er min test side til tasteamazon.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
</head>
<body>
    <button class="btn btn-primary">Dette er min test side til tasteamazon.com - :P</button>
</BODY>
</HTML>
<?php }
}
